
import React, { useState, useEffect, useMemo } from 'react';
import { TrainingMode, AimProfile, SessionStats, AIAnalysis } from './types';
import { DEFAULT_PROFILES, MODE_CONFIGS } from './constants';
import AimEngine from './components/AimEngine';
import Dashboard from './components/Dashboard';
import { analyzePerformance } from './services/aiService';
import { 
  Settings as SettingsIcon, 
  LayoutDashboard, 
  Target, 
  Zap, 
  Activity, 
  Crosshair, 
  Plus, 
  Trash2, 
  Save, 
  Gamepad2, 
  MousePointer2, 
  Download, 
  Copy, 
  Eye, 
  Mail, 
  Lock, 
  ChevronRight,
  LogOut,
  Chrome,
  Apple,
  User as UserIcon,
  Check
} from 'lucide-react';

const CrosshairPreview = ({ profile, label }: { profile: any, label?: string }) => {
  const { size, thickness, gap, color, outline } = profile.crosshair || profile;
  
  return (
    <div className="flex flex-col items-center gap-2">
      {label && <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</span>}
      <div className="w-32 h-32 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center relative overflow-hidden shadow-inner">
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #334155 1px, transparent 1px)', backgroundSize: '16px 16px' }}></div>
        <div className="relative">
          {/* Horizontal Lines */}
          <div style={{
            position: 'absolute',
            left: -gap - size,
            top: -thickness / 2,
            width: size,
            height: thickness,
            backgroundColor: color,
            boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none'
          }} />
          <div style={{
            position: 'absolute',
            left: gap,
            top: -thickness / 2,
            width: size,
            height: thickness,
            backgroundColor: color,
            boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none'
          }} />
          {/* Vertical Lines */}
          <div style={{
            position: 'absolute',
            top: -gap - size,
            left: -thickness / 2,
            width: thickness,
            height: size,
            backgroundColor: color,
            boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none'
          }} />
          <div style={{
            position: 'absolute',
            top: gap,
            left: -thickness / 2,
            width: thickness,
            height: size,
            backgroundColor: color,
            boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none'
          }} />
        </div>
      </div>
    </div>
  );
};

const AuthScreen = ({ onLogin }: { onLogin: (user: string) => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      onLogin(email.split('@')[0]);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center p-6 relative overflow-hidden font-sans">
      {/* Background elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-emerald-600/10 blur-[120px] rounded-full"></div>
      
      <div className="w-full max-w-md z-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center font-black italic text-5xl shadow-2xl mx-auto mb-6 text-slate-950">A</div>
          <h1 className="text-4xl font-black italic tracking-tighter text-white uppercase leading-none mb-2">AIMLAB <span className="text-blue-500">PRO</span></h1>
          <p className="text-slate-500 font-medium uppercase tracking-[0.2em] text-[10px]">Geleceğin E-Sporcusu Burada Yetişiyor</p>
        </div>

        <div className="bg-slate-900/50 backdrop-blur-3xl border border-slate-800 rounded-[2.5rem] p-10 shadow-2xl">
          <div className="flex gap-1 mb-8 bg-slate-950/50 p-1.5 rounded-2xl border border-slate-800">
            <button 
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3 rounded-xl font-black text-xs transition-all uppercase ${isLogin ? 'bg-white text-slate-950 shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Giriş Yap
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3 rounded-xl font-black text-xs transition-all uppercase ${!isLogin ? 'bg-white text-slate-950 shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}
            >
              Kayıt Ol
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">E-Posta Adresi</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-blue-500 transition-colors" size={18} />
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="isim@example.com"
                  className="w-full bg-slate-950 border border-slate-800 p-4 pl-12 rounded-2xl text-sm font-medium text-white outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Parola</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-blue-500 transition-colors" size={18} />
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-800 p-4 pl-12 rounded-2xl text-sm font-medium text-white outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                  required
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-blue-500 shadow-xl shadow-blue-600/20 transition-all hover:scale-[1.02] active:scale-95 mt-4"
            >
              {isLogin ? 'Oturum Aç' : 'Hesap Oluştur'} <ChevronRight size={18} />
            </button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-800"></div></div>
            <div className="relative flex justify-center text-[10px]"><span className="bg-slate-900 px-4 text-slate-600 font-black uppercase tracking-widest">veya</span></div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => onLogin('GoogleUser')}
              className="bg-slate-950 border border-slate-800 p-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-slate-800 transition-all"
            >
              <Chrome size={20} className="text-white" />
              <span className="text-xs font-black text-white uppercase tracking-tighter">Google</span>
            </button>
            <button 
              onClick={() => onLogin('AppleUser')}
              className="bg-slate-950 border border-slate-800 p-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-slate-800 transition-all"
            >
              <Apple size={20} className="text-white" />
              <span className="text-xs font-black text-white uppercase tracking-tighter">Apple</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [user, setUser] = useState<string | null>(null);
  const [userNameInput, setUserNameInput] = useState<string>('');
  const [currentMode, setCurrentMode] = useState<TrainingMode | null>(null);
  const [profiles, setProfiles] = useState<AimProfile[]>(DEFAULT_PROFILES);
  const [activeProfileId, setActiveProfileId] = useState<string>(DEFAULT_PROFILES[0].id);
  const [sessions, setSessions] = useState<SessionStats[]>([]);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysis | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'training' | 'settings'>('dashboard');
  const [importCode, setImportCode] = useState('');

  const activeProfile = profiles.find(p => p.id === activeProfileId) || profiles[0];

  const parseCode = (code: string): any => {
    if (!code) return null;
    const settings: any = { ...activeProfile.crosshair };
    
    if (code.includes(';')) {
      const parts = code.split(';');
      const valorantColors = ['#ffffff', '#4ade80', '#eab308', '#3b82f6', '#22d3ee', '#f472b6', '#ef4444', '#fb923c'];
      
      for (let i = 0; i < parts.length; i++) {
        const key = parts[i];
        const val = parts[i + 1];
        if (key === 'c') settings.color = valorantColors[parseInt(val)] || settings.color;
        if (key === 'o') settings.outline = val === '1';
        if (key === '0t') settings.thickness = parseFloat(val);
        if (key === '0l') settings.size = parseFloat(val);
        if (key === '0o') settings.gap = parseFloat(val);
        if (key === '1t' && !parts.includes('0t')) settings.thickness = parseFloat(val);
        if (key === '1l' && !parts.includes('0l')) settings.size = parseFloat(val);
        if (key === '1o' && !parts.includes('0o')) settings.gap = parseFloat(val);
      }
      return settings;
    } else if (code.includes('|')) {
      const parts = code.split('|');
      parts.forEach(p => {
        const [key, val] = p.split(':');
        if (key === 'S') settings.size = parseFloat(val);
        if (key === 'T') settings.thickness = parseFloat(val);
        if (key === 'G') settings.gap = parseFloat(val);
        if (key === 'C') settings.color = '#' + val;
        if (key === 'O') settings.outline = val === '1';
      });
      return settings;
    }
    return null;
  };

  const previewCrosshair = useMemo(() => {
    const parsed = parseCode(importCode);
    return parsed ? { crosshair: parsed } : null;
  }, [importCode, activeProfile.crosshair]);

  useEffect(() => {
    const savedAuth = localStorage.getItem('aim_auth');
    if (savedAuth) {
      setIsAuthenticated(true);
      setUser(savedAuth);
      setUserNameInput(savedAuth);
    }

    const savedSessions = localStorage.getItem('aim_sessions');
    if (savedSessions) {
      const parsed = JSON.parse(savedSessions);
      setSessions(parsed);
      if (parsed.length > 0) analyzePerformance(parsed).then(setAiAnalysis);
    }
    const savedProfiles = localStorage.getItem('aim_profiles');
    if (savedProfiles) setProfiles(JSON.parse(savedProfiles));
    const savedActiveId = localStorage.getItem('aim_active_profile');
    if (savedActiveId) setActiveProfileId(savedActiveId);
  }, []);

  const handleLogin = (userName: string) => {
    setIsAuthenticated(true);
    setUser(userName);
    setUserNameInput(userName);
    localStorage.setItem('aim_auth', userName);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('aim_auth');
  };

  const updateUserName = () => {
    if (userNameInput.trim()) {
      setUser(userNameInput.trim());
      localStorage.setItem('aim_auth', userNameInput.trim());
    }
  };

  const saveToStorage = (newProfiles: AimProfile[], newActiveId: string) => {
    localStorage.setItem('aim_profiles', JSON.stringify(newProfiles));
    localStorage.setItem('aim_active_profile', newActiveId);
  };

  const handleSessionComplete = (stats: SessionStats) => {
    const newSessions = [...sessions, stats];
    setSessions(newSessions);
    localStorage.setItem('aim_sessions', JSON.stringify(newSessions));
    setCurrentMode(null);
    setActiveTab('dashboard');
    analyzePerformance(newSessions).then(setAiAnalysis);
  };

  const updateProfile = (updated: AimProfile) => {
    const newProfiles = profiles.map(p => p.id === updated.id ? updated : p);
    setProfiles(newProfiles);
    saveToStorage(newProfiles, activeProfileId);
  };

  const createNewProfile = () => {
    const newId = Math.random().toString(36).substr(2, 9);
    const newProfile: AimProfile = {
      ...activeProfile,
      id: newId,
      name: `Özel ${profiles.length + 1}`,
    };
    const newProfiles = [...profiles, newProfile];
    setProfiles(newProfiles);
    setActiveProfileId(newId);
    saveToStorage(newProfiles, newId);
  };

  const deleteProfile = (id: string) => {
    if (profiles.length <= 1) return;
    const newProfiles = profiles.filter(p => p.id !== id);
    const nextId = newProfiles[0].id;
    setProfiles(newProfiles);
    setActiveProfileId(nextId);
    saveToStorage(newProfiles, nextId);
  };

  const generateCrosshairCode = (p: AimProfile) => {
    const { size, thickness, gap, color, outline } = p.crosshair;
    return `0;P;c;5;o;${outline ? 1 : 0};0t;${thickness};0l;${size};0o;${gap};0a;1;0f;0;1b;0`;
  };

  const applyCrosshairCode = (code: string) => {
    const parsed = parseCode(code);
    if (parsed) {
      updateProfile({
        ...activeProfile,
        crosshair: parsed
      });
      setImportCode('');
    } else if (code) {
      alert("Geçersiz nişangah kodu!");
    }
  };

  if (!isAuthenticated) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  if (currentMode) {
    return (
      <AimEngine 
        mode={currentMode} 
        profile={activeProfile} 
        onSessionComplete={handleSessionComplete}
        onExit={() => setCurrentMode(null)}
      />
    );
  }

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-500/30">
      <nav className="w-20 lg:w-72 bg-slate-900 border-r border-slate-800 flex flex-col justify-between py-8 px-4 overflow-hidden">
        <div className="space-y-8">
          <div className="flex items-center gap-3 px-2">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center font-black italic text-3xl shadow-xl shadow-white/5 text-slate-950">A</div>
            <div className="hidden lg:block">
              <span className="font-black text-xl italic tracking-tighter block leading-none">AIMLAB <span className="text-blue-500">PRO</span></span>
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest uppercase">E-Spor Simülatörü</span>
            </div>
          </div>

          <div className="space-y-1">
            <button onClick={() => setActiveTab('dashboard')} className={`w-full flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${activeTab === 'dashboard' ? 'bg-blue-600 text-white shadow-2xl shadow-blue-600/30' : 'text-slate-400 hover:bg-slate-800'}`}>
              <LayoutDashboard size={20} /><span className="hidden lg:block font-bold uppercase text-xs tracking-widest">Ana Panel</span>
            </button>
            <button onClick={() => setActiveTab('training')} className={`w-full flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${activeTab === 'training' ? 'bg-blue-600 text-white shadow-2xl shadow-blue-600/30' : 'text-slate-400 hover:bg-slate-800'}`}>
              <Target size={20} /><span className="hidden lg:block font-bold uppercase text-xs tracking-widest">Eğitim Alanı</span>
            </button>
            <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center gap-3 px-4 py-4 rounded-2xl transition-all ${activeTab === 'settings' ? 'bg-blue-600 text-white shadow-2xl shadow-blue-600/30' : 'text-slate-400 hover:bg-slate-800'}`}>
              <SettingsIcon size={20} /><span className="hidden lg:block font-bold uppercase text-xs tracking-widest">Oyun Profilleri</span>
            </button>
          </div>
        </div>

        <div className="space-y-4">
           <div className="hidden lg:block p-4 bg-slate-950 border border-slate-800 rounded-2xl">
              <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2">Profilim</p>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center font-black text-xs">{user?.[0]?.toUpperCase()}</div>
                <div className="flex-1 overflow-hidden">
                  <p className="text-xs font-black truncate">{user}</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter">Elite Member</p>
                </div>
              </div>
           </div>
           <button 
             onClick={handleLogout}
             className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl text-red-500 hover:bg-red-500/10 transition-all"
           >
             <LogOut size={20} /><span className="hidden lg:block font-bold uppercase text-xs tracking-widest">Çıkış Yap</span>
           </button>
        </div>
      </nav>

      <main className="flex-1 overflow-y-auto bg-slate-950 scroll-smooth">
        {activeTab === 'dashboard' && <Dashboard sessions={sessions} aiAnalysis={aiAnalysis} onStartTraining={setCurrentMode} />}

        {activeTab === 'training' && (
          <div className="max-w-7xl mx-auto p-12 animate-in fade-in duration-700">
            <div className="mb-12">
              <h1 className="text-6xl font-black italic tracking-tighter mb-4 text-white uppercase">Mod Seçin</h1>
              <p className="text-slate-500 font-medium uppercase tracking-widest text-xs">Aktif Profil: <span className="text-blue-500 font-bold">{activeProfile.name}</span></p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {Object.entries(MODE_CONFIGS).map(([mode, config]) => (
                <button
                  key={mode}
                  onClick={() => setCurrentMode(mode as TrainingMode)}
                  className="group relative h-96 bg-slate-900/50 border border-slate-800 rounded-[3rem] p-10 flex flex-col justify-end text-left overflow-hidden hover:border-blue-500/50 transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-blue-500/5"
                >
                  <div className="absolute top-0 right-0 p-10 text-slate-800/30 group-hover:text-blue-500/10 transition-colors">
                    {mode === TrainingMode.STATIC && <Target size={160} />}
                    {mode === TrainingMode.TRACKING && <Activity size={160} />}
                    {mode === TrainingMode.FLICK && <Zap size={160} />}
                    {mode === TrainingMode.SPRAY && <Crosshair size={160} />}
                  </div>
                  <div className="relative z-10">
                    <h2 className="text-4xl font-black italic leading-none mb-4 text-white uppercase">{config.name}</h2>
                    <p className="text-slate-500 text-sm leading-relaxed mb-8">{config.description}</p>
                    <div className="inline-flex items-center gap-4 bg-white text-slate-950 px-6 py-3 rounded-full font-black text-sm group-hover:bg-blue-500 group-hover:text-white transition-all">
                      <span>BAŞLAT</span>
                      <Zap size={14} />
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-4xl mx-auto p-12 animate-in slide-in-from-bottom-8 duration-700 space-y-12">
            <div>
              <h1 className="text-6xl font-black italic tracking-tighter text-white uppercase mb-12">Ayarlar</h1>
              
              {/* User Profile Section */}
              <div className="bg-slate-900 border border-slate-800 p-10 rounded-[3rem] space-y-8 shadow-2xl relative overflow-hidden mb-10">
                <h3 className="text-xl font-black italic text-white flex items-center gap-2 uppercase mb-6">
                  <UserIcon className="text-blue-500" /> Kullanıcı Profili
                </h3>
                <div className="space-y-4 max-w-md">
                  <label className="text-xs font-black text-slate-500 uppercase tracking-widest ml-1">Görünen İsim</label>
                  <div className="flex gap-3">
                    <div className="relative flex-1">
                      <input 
                        type="text" 
                        value={userNameInput}
                        onChange={(e) => setUserNameInput(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-blue-500 transition-all"
                        placeholder="Yeni isminiz..."
                      />
                    </div>
                    <button 
                      onClick={updateUserName}
                      className="bg-blue-600 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase hover:bg-blue-500 transition-all flex items-center gap-2"
                    >
                      <Check size={18} /> GÜNCELLE
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black italic tracking-tighter text-white uppercase">Oyun Senkronizasyonu</h2>
                <button onClick={createNewProfile} className="bg-white text-slate-950 px-6 py-3 rounded-2xl font-black flex items-center gap-2 hover:bg-blue-500 hover:text-white transition-all">
                  <Plus size={20} /> YENİ PROFİL
                </button>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-10 rounded-[3rem] space-y-10 shadow-2xl relative overflow-hidden">
                <div className="flex items-center justify-between border-b border-slate-800 pb-8">
                  <div className="space-y-1">
                    <p className="text-xs font-black text-slate-500 uppercase tracking-widest">Düzenlenen Profil</p>
                    <input 
                      className="bg-transparent text-3xl font-black text-white italic tracking-tighter outline-none focus:text-blue-500 transition-colors w-full"
                      value={activeProfile.name}
                      onChange={(e) => updateProfile({...activeProfile, name: e.target.value})}
                    />
                  </div>
                  <button onClick={() => deleteProfile(activeProfileId)} className="p-4 bg-red-500/10 text-red-500 rounded-2xl hover:bg-red-500 hover:text-white transition-all">
                    <Trash2 size={24} />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="space-y-8">
                    <h3 className="text-xl font-black italic text-white flex items-center gap-2 uppercase">
                      <Gamepad2 className="text-blue-500" /> Oyun Ayarları
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      {['VALORANT', 'CS2'].map(g => (
                        <button
                          key={g}
                          onClick={() => updateProfile({...activeProfile, game: g as any})}
                          className={`py-4 rounded-2xl font-black tracking-widest uppercase transition-all ${activeProfile.game === g ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/20' : 'bg-slate-950 text-slate-500 border border-slate-800'}`}
                        >
                          {g}
                        </button>
                      ))}
                    </div>

                    <div className="space-y-6 bg-slate-950/50 p-6 rounded-3xl border border-slate-800">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-black text-slate-500 uppercase tracking-widest">Hassasiyet</span>
                        <span className="text-xl font-mono text-blue-400 font-bold">{activeProfile.sensitivity}</span>
                      </div>
                      <input 
                        type="range" min="0.01" max="5.0" step="0.01"
                        value={activeProfile.sensitivity}
                        onChange={(e) => updateProfile({...activeProfile, sensitivity: parseFloat(e.target.value)})}
                        className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>

                    <div className="space-y-4">
                       <span className="text-xs font-black text-slate-500 uppercase tracking-widest block uppercase">Ateş Tuşu</span>
                       <div className="grid grid-cols-2 gap-4">
                        <button 
                          onClick={() => updateProfile({...activeProfile, shootingButton: 'left'})}
                          className={`py-4 rounded-xl font-black flex items-center justify-center gap-2 transition-all ${activeProfile.shootingButton === 'left' ? 'bg-blue-600 text-white' : 'bg-slate-950 text-slate-500 border border-slate-800'}`}
                        >
                          <MousePointer2 size={16} /> SOL TIK
                        </button>
                        <button 
                          onClick={() => updateProfile({...activeProfile, shootingButton: 'right'})}
                          className={`py-4 rounded-xl font-black flex items-center justify-center gap-2 transition-all ${activeProfile.shootingButton === 'right' ? 'bg-blue-600 text-white' : 'bg-slate-950 text-slate-500 border border-slate-800'}`}
                        >
                          <MousePointer2 size={16} /> SAĞ TIK
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-8">
                    <h3 className="text-xl font-black italic text-white flex items-center gap-2 uppercase">
                      <Crosshair className="text-emerald-500" /> Nişangah Tasarımı
                    </h3>
                    
                    <div className="flex justify-center gap-4 py-4">
                      <CrosshairPreview profile={activeProfile} label="Aktif" />
                      {previewCrosshair && (
                        <div className="animate-in fade-in slide-in-from-right-2 duration-300">
                          <CrosshairPreview profile={previewCrosshair} label="Yeni Kod" />
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block">Boyut</span>
                        <input type="number" step="0.5" value={activeProfile.crosshair.size} onChange={(e) => updateProfile({...activeProfile, crosshair: {...activeProfile.crosshair, size: parseFloat(e.target.value)}})} className="w-full bg-slate-950 border border-slate-800 p-3 rounded-xl font-mono text-sm outline-none focus:border-emerald-500" />
                      </div>
                      <div className="space-y-2">
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block">Kalınlık</span>
                        <input type="number" step="1" value={activeProfile.crosshair.thickness} onChange={(e) => updateProfile({...activeProfile, crosshair: {...activeProfile.crosshair, thickness: parseInt(e.target.value)}})} className="w-full bg-slate-950 border border-slate-800 p-3 rounded-xl font-mono text-sm outline-none focus:border-emerald-500" />
                      </div>
                    </div>

                    <div className="pt-6 border-t border-slate-800 space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-black text-slate-500 uppercase tracking-widest">Nişangah Kodu (Valorant)</span>
                        <button onClick={() => { const code = generateCrosshairCode(activeProfile); navigator.clipboard.writeText(code); }} className="text-[10px] font-bold text-blue-400 flex items-center gap-1 hover:text-white transition-colors">
                          <Copy size={12}/> KOPYALA
                        </button>
                      </div>
                      <div className="flex gap-2">
                        <input 
                          placeholder="Valorant kodunu buraya yapıştırın..."
                          className="flex-1 bg-slate-950 border border-slate-800 p-3 rounded-xl font-mono text-xs outline-none focus:border-blue-500 placeholder:text-slate-700"
                          value={importCode}
                          onChange={(e) => setImportCode(e.target.value)}
                        />
                        <button 
                          onClick={() => applyCrosshairCode(importCode)}
                          className={`px-6 py-3 rounded-xl font-black text-xs transition-all uppercase whitespace-nowrap ${importCode ? 'bg-blue-600 text-white hover:bg-blue-500' : 'bg-slate-800 text-slate-600 cursor-not-allowed'}`}
                        >
                          YÜKLE
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-10 border-t border-slate-800 flex justify-end">
                  <div className="bg-emerald-500/10 text-emerald-500 px-8 py-4 rounded-2xl font-black uppercase tracking-widest flex items-center gap-3">
                    <Save size={20} /> Profil Kaydedildi
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
