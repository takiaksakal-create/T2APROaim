
export enum TrainingMode {
  STATIC = 'STATIC',
  TRACKING = 'TRACKING',
  FLICK = 'FLICK',
  SPRAY = 'SPRAY'
}

export type GameEngineType = 'CS2' | 'VALORANT';

export interface AimProfile {
  id: string;
  name: string;
  game: GameEngineType;
  dpi: number;
  sensitivity: number;
  fov: number;
  shootingButton: 'left' | 'right';
  crosshair: {
    size: number;
    thickness: number;
    gap: number;
    color: string;
    outline: boolean;
  };
  targetSettings: {
    color: string;
    size: number;
    spawnRate: number;
  };
}

export interface GameSettings {
  activeProfileId: string;
  profiles: AimProfile[];
}

export interface Target {
  id: string;
  x: number;
  y: number;
  radius: number;
  vx?: number;
  vy?: number;
  spawnTime: number;
  isFlick?: boolean;
}

export interface SessionStats {
  mode: TrainingMode;
  profileName: string;
  hits: number;
  misses: number;
  headshots: number;
  reactionTimes: number[];
  trackingDuration: number;
  startTime: number;
  endTime: number;
}

export interface AIAnalysis {
  feedback: string;
  recommendation: TrainingMode;
  scores: {
    accuracy: number;
    speed: number;
    consistency: number;
  };
}
