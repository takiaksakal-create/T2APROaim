
import { GoogleGenAI, Type } from "@google/genai";
import { SessionStats, AIAnalysis, TrainingMode } from "../types";

export const analyzePerformance = async (sessions: SessionStats[]): Promise<AIAnalysis> => {
  // Always initialize a new client within the request scope to use the most current API key
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-flash-preview";
  
  const statsSummary = sessions.map(s => ({
    mode: s.mode,
    accuracy: (s.hits / (s.hits + s.misses || 1)) * 100,
    avgReactionTime: s.reactionTimes.length > 0 
      ? s.reactionTimes.reduce((a, b) => a + b, 0) / s.reactionTimes.length 
      : 0,
    totalTargets: s.hits + s.misses
  }));

  const prompt = `Analyze these aim trainer sessions: ${JSON.stringify(statsSummary)}. 
    Provide a professional e-sports coach feedback. 
    Keep it concise and actionable.
    Identify strengths and weaknesses.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            feedback: { type: Type.STRING },
            recommendation: { 
              type: Type.STRING,
              description: "One of: STATIC, TRACKING, FLICK, SPRAY"
            },
            scores: {
              type: Type.OBJECT,
              properties: {
                accuracy: { type: Type.NUMBER },
                speed: { type: Type.NUMBER },
                consistency: { type: Type.NUMBER }
              },
              required: ["accuracy", "speed", "consistency"]
            }
          },
          required: ["feedback", "recommendation", "scores"]
        }
      }
    });

    // Access the text property directly from the response object
    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return {
      feedback: "Your accuracy is improving. Focus on maintaining consistent mouse movements during tracking.",
      recommendation: TrainingMode.TRACKING,
      scores: { accuracy: 75, speed: 60, consistency: 80 }
    };
  }
};
