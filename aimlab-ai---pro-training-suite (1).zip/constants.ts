
import { AimProfile, TrainingMode } from './types';

export const DEFAULT_PROFILES: AimProfile[] = [
  {
    id: 'val-default',
    name: 'Valorant Standard',
    game: 'VALORANT',
    dpi: 800,
    sensitivity: 0.35,
    fov: 103,
    shootingButton: 'left',
    crosshair: {
      size: 4,
      thickness: 2,
      gap: 0,
      color: '#4ade80',
      outline: true,
    },
    targetSettings: {
      color: '#ef4444',
      size: 25,
      spawnRate: 1000,
    }
  },
  {
    id: 'cs2-default',
    name: 'CS2 Competitive',
    game: 'CS2',
    dpi: 800,
    sensitivity: 1.2,
    fov: 90,
    shootingButton: 'left',
    crosshair: {
      size: 3,
      thickness: 1,
      gap: -1,
      color: '#ffffff',
      outline: false,
    },
    targetSettings: {
      color: '#eab308',
      size: 20,
      spawnRate: 800,
    }
  }
];

export const MODE_CONFIGS = {
  [TrainingMode.STATIC]: {
    name: 'Static Aim',
    description: 'Precision training with stationary targets. Replicates holding angles or clearing corners.',
    icon: 'Target',
  },
  [TrainingMode.TRACKING]: {
    name: 'Tracking',
    description: 'Follow moving targets smoothly. Essential for tracking enemies in high-mobility encounters.',
    icon: 'Activity',
  },
  [TrainingMode.FLICK]: {
    name: 'Flick Shot',
    description: 'Reactive target acquisition. Train your reflexes for sudden encounters.',
    icon: 'Zap',
  },
  [TrainingMode.SPRAY]: {
    name: 'Spray Control',
    description: 'Master recoil patterns. Simulate full-auto fire control for your chosen game.',
    icon: 'Crosshair',
  },
};
