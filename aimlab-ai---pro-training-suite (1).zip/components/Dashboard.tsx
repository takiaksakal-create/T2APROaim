
import React from 'react';
import { SessionStats, AIAnalysis } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Target, Activity, Zap, Crosshair, BrainCircuit, TrendingUp, Trophy } from 'lucide-react';

interface DashboardProps {
  sessions: SessionStats[];
  aiAnalysis: AIAnalysis | null;
  onStartTraining: (mode: any) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ sessions, aiAnalysis, onStartTraining }) => {
  const chartData = sessions.slice(-10).map((s, i) => ({
    name: `S${i+1}`,
    accuracy: (s.hits / (s.hits + s.misses || 1)) * 100,
    hits: s.hits,
    reaction: s.reactionTimes.length > 0 ? s.reactionTimes.reduce((a,b)=>a+b,0) / s.reactionTimes.length : 0
  }));

  const totalHits = sessions.reduce((sum, s) => sum + s.hits, 0);
  const avgAccuracy = sessions.length > 0 
    ? sessions.reduce((sum, s) => sum + (s.hits / (s.hits + s.misses || 1)) * 100, 0) / sessions.length 
    : 0;

  return (
    <div className="max-w-7xl mx-auto p-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-5xl font-black italic tracking-tighter text-white">COMMAND CENTER</h1>
          <p className="text-slate-400 mt-2 font-medium">Welcome back, Soldier. Your performance is being monitored.</p>
        </div>
        <div className="flex gap-4">
           <div className="text-right">
             <p className="text-xs text-slate-500 uppercase font-bold tracking-widest">Global Rank</p>
             <p className="text-2xl font-black text-emerald-500">DIAMOND II</p>
           </div>
        </div>
      </header>

      {/* AI Intelligence Block */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <BrainCircuit size={120} />
          </div>
          <div className="flex items-center gap-2 mb-4">
            <BrainCircuit className="text-blue-400" size={24} />
            <h3 className="text-xl font-bold">AI STRATEGIC ADVISOR</h3>
          </div>
          {aiAnalysis ? (
            <div className="space-y-6">
              <p className="text-slate-300 leading-relaxed text-lg">
                "{aiAnalysis.feedback}"
              </p>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/50">
                  <p className="text-xs text-slate-500 uppercase font-bold mb-1">Accuracy</p>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500" style={{ width: `${aiAnalysis.scores.accuracy}%` }} />
                  </div>
                </div>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/50">
                  <p className="text-xs text-slate-500 uppercase font-bold mb-1">Speed</p>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500" style={{ width: `${aiAnalysis.scores.speed}%` }} />
                  </div>
                </div>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/50">
                  <p className="text-xs text-slate-500 uppercase font-bold mb-1">Consistency</p>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-500" style={{ width: `${aiAnalysis.scores.consistency}%` }} />
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                 <div className="bg-emerald-500 p-2 rounded-lg text-slate-950">
                   <TrendingUp size={20} />
                 </div>
                 <div>
                   <p className="text-sm font-bold text-emerald-400 uppercase">Recommended Focus</p>
                   <p className="text-slate-300">Intensive {aiAnalysis.recommendation} drills to normalize reaction delay.</p>
                 </div>
              </div>
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-slate-500 animate-pulse">
              Analyzing combat data...
            </div>
          )}
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl">
                <Trophy size={24} />
              </div>
              <span className="text-slate-500 text-sm font-bold">ALL TIME STATS</span>
            </div>
            <div>
              <p className="text-4xl font-black text-white">{totalHits}</p>
              <p className="text-slate-500 uppercase text-xs font-bold tracking-widest mt-1">Total Targets Eliminated</p>
            </div>
            <div>
              <p className="text-4xl font-black text-emerald-500">{Math.round(avgAccuracy)}%</p>
              <p className="text-slate-500 uppercase text-xs font-bold tracking-widest mt-1">Average Global Accuracy</p>
            </div>
          </div>
          <button className="w-full bg-white text-slate-950 py-4 rounded-xl font-bold hover:bg-slate-200 transition-colors uppercase tracking-widest">
            View Career Profile
          </button>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <TrendingUp size={18} className="text-emerald-500" />
            Accuracy Progression
          </h3>
          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#10b981' }}
                />
                <Line type="monotone" dataKey="accuracy" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <Zap size={18} className="text-blue-500" />
            Reaction Time (ms)
          </h3>
          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#3b82f6' }}
                />
                <Bar dataKey="reaction" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
