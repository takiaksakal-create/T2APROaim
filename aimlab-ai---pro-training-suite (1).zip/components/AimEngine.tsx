
import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import { AimProfile, TrainingMode, Target as TargetData, SessionStats } from '../types';
import { Zap, Target, Settings, Play, LogOut, MousePointer2, Copy, Download, Eye } from 'lucide-react';

interface AimEngineProps {
  mode: TrainingMode;
  profile: AimProfile;
  onSessionComplete: (stats: SessionStats) => void;
  onExit: () => void;
}

const CrosshairPreview = ({ profile, label }: { profile: any, label?: string }) => {
  const { size, thickness, gap, color, outline } = profile.crosshair || profile;
  return (
    <div className="flex flex-col items-center gap-1">
      {label && <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</span>}
      <div className="w-24 h-24 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center relative overflow-hidden">
        <div className="relative">
          <div style={{ position: 'absolute', left: -gap - size, top: -thickness / 2, width: size, height: thickness, backgroundColor: color, boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none' }} />
          <div style={{ position: 'absolute', left: gap, top: -thickness / 2, width: size, height: thickness, backgroundColor: color, boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none' }} />
          <div style={{ position: 'absolute', top: -gap - size, left: -thickness / 2, width: thickness, height: size, backgroundColor: color, boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none' }} />
          <div style={{ position: 'absolute', top: gap, left: -thickness / 2, width: thickness, height: size, backgroundColor: color, boxShadow: outline ? `0 0 0 1px rgba(0,0,0,0.8)` : 'none' }} />
        </div>
      </div>
    </div>
  );
};

const AimEngine: React.FC<AimEngineProps> = ({ mode, profile: initialProfile, onSessionComplete, onExit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const [currentProfile, setCurrentProfile] = useState<AimProfile>(initialProfile);
  const [targets, setTargets] = useState<TargetData[]>([]);
  const [crosshairCode, setCrosshairCode] = useState('');
  
  const [viewOffset, setViewOffset] = useState({ x: 0, y: 0 });
  const [weaponSway, setWeaponSway] = useState({ x: 0, y: 0 });
  const [recoilOffset, setRecoilOffset] = useState({ x: 0, y: 0 });
  
  const [isFiring, setIsFiring] = useState(false);
  const [muzzleFlash, setMuzzleFlash] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const fireStartTime = useRef<number>(0);
  const requestRef = useRef<number>();
  const lastTimeRef = useRef<number>();

  const [stats, setStats] = useState<SessionStats>({
    mode,
    profileName: currentProfile.name,
    hits: 0,
    misses: 0,
    headshots: 0,
    reactionTimes: [],
    trackingDuration: 0,
    startTime: Date.now(),
    endTime: 0
  });
  
  const [timeLeft, setTimeLeft] = useState(30);
  const [isActive, setIsActive] = useState(false);

  const WORLD_WIDTH = 3000;
  const WORLD_HEIGHT = 2000;
  const SPAWN_WIDTH = 1200; 
  const SPAWN_HEIGHT = 800;

  const parseCode = (code: string): any => {
    if (!code) return null;
    const settings: any = { ...currentProfile.crosshair };
    if (code.includes(';')) {
      const parts = code.split(';');
      const valorantColors = ['#ffffff', '#4ade80', '#eab308', '#3b82f6', '#22d3ee', '#f472b6', '#ef4444', '#fb923c'];
      for (let i = 0; i < parts.length; i++) {
        const key = parts[i];
        const val = parts[i + 1];
        if (key === 'c') settings.color = valorantColors[parseInt(val)] || settings.color;
        if (key === 'o') settings.outline = val === '1';
        if (key === '0t') settings.thickness = parseFloat(val);
        if (key === '0l') settings.size = parseFloat(val);
        if (key === '0o') settings.gap = parseFloat(val);
        if (key === '1t' && !parts.includes('0t')) settings.thickness = parseFloat(val);
        if (key === '1l' && !parts.includes('0l')) settings.size = parseFloat(val);
        if (key === '1o' && !parts.includes('0o')) settings.gap = parseFloat(val);
      }
      return settings;
    } else if (code.includes('|')) {
      const parts = code.split('|');
      parts.forEach(p => {
        const [key, val] = p.split(':');
        if (key === 'S') settings.size = parseFloat(val);
        if (key === 'T') settings.thickness = parseFloat(val);
        if (key === 'G') settings.gap = parseFloat(val);
        if (key === 'C') settings.color = '#' + val;
        if (key === 'O') settings.outline = val === '1';
      });
      return settings;
    }
    return null;
  };

  const previewCrosshair = useMemo(() => {
    const parsed = parseCode(crosshairCode);
    return parsed ? { crosshair: parsed } : null;
  }, [crosshairCode, currentProfile.crosshair]);

  const applyCrosshairCode = (code: string) => {
    const parsed = parseCode(code);
    if (parsed) {
      setCurrentProfile(prev => ({ ...prev, crosshair: parsed }));
      setCrosshairCode('');
    }
  };

  const createTarget = useCallback((): TargetData => {
    const size = currentProfile.targetSettings.size;
    const centerX = WORLD_WIDTH / 2;
    const centerY = WORLD_HEIGHT / 2;
    return {
      id: Math.random().toString(36).substr(2, 9),
      x: centerX - (SPAWN_WIDTH / 2) + Math.random() * SPAWN_WIDTH,
      y: centerY - (SPAWN_HEIGHT / 2) + Math.random() * SPAWN_HEIGHT,
      radius: size,
      spawnTime: Date.now(),
      vx: mode === TrainingMode.TRACKING ? (Math.random() - 0.5) * (currentProfile.game === 'CS2' ? 12 : 8) : 0,
      vy: mode === TrainingMode.TRACKING ? (Math.random() - 0.5) * (currentProfile.game === 'CS2' ? 8 : 5) : 0,
      isFlick: mode === TrainingMode.FLICK
    };
  }, [mode, currentProfile.targetSettings.size, currentProfile.game]);

  const spawnTargetsInitial = useCallback(() => {
    const initialTargets = Array.from({ length: 7 }, () => createTarget());
    setTargets(initialTargets);
    setViewOffset({ x: WORLD_WIDTH / 2, y: WORLD_HEIGHT / 2 });
  }, [createTarget]);

  useEffect(() => {
    if (isActive && !isPaused) {
      if (targets.length === 0) spawnTargetsInitial();
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            setIsActive(false);
            if (document.pointerLockElement) document.exitPointerLock();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isActive, isPaused, spawnTargetsInitial, targets.length]);

  const handleStart = async () => {
    try { if (containerRef.current && !document.fullscreenElement) await containerRef.current.requestFullscreen(); } catch (err) {}
    setIsActive(true); setIsPaused(false); setShowSettings(false);
    canvasRef.current?.requestPointerLock();
  };

  const handleResume = () => { setIsPaused(false); setShowSettings(false); canvasRef.current?.requestPointerLock(); };
  const handleAbort = () => { if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); onExit(); };

  const updateRecoil = useCallback(() => {
    if (mode !== TrainingMode.SPRAY || !isFiring || isPaused) { setRecoilOffset({ x: 0, y: 0 }); return; }
    const elapsed = Date.now() - fireStartTime.current;
    const intensity = currentProfile.game === 'CS2' ? 1.8 : 1.2;
    const ry = -Math.min(elapsed / 10, 130) * intensity;
    const rx = Math.sin(elapsed / 60) * (elapsed / 20) * intensity;
    setRecoilOffset({ x: rx, y: ry });
  }, [mode, isFiring, isPaused, currentProfile.game]);

  const animate = (time: number) => {
    if (lastTimeRef.current !== undefined && canvasRef.current) {
      const deltaTime = time - lastTimeRef.current;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;
      const { width, height } = canvasRef.current;
      ctx.fillStyle = '#020617'; ctx.fillRect(0, 0, width, height);

      const wallScreenX = (WORLD_WIDTH / 2 - SPAWN_WIDTH / 2 - viewOffset.x) + width / 2;
      const wallScreenY = (WORLD_HEIGHT / 2 - SPAWN_HEIGHT / 2 - (viewOffset.y + recoilOffset.y)) + height / 2;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.8)'; ctx.fillRect(wallScreenX - 50, wallScreenY - 50, SPAWN_WIDTH + 100, SPAWN_HEIGHT + 100);
      ctx.strokeStyle = '#1e293b'; ctx.lineWidth = 4; ctx.strokeRect(wallScreenX - 50, wallScreenY - 50, SPAWN_WIDTH + 100, SPAWN_HEIGHT + 100);

      ctx.strokeStyle = 'rgba(30, 41, 59, 0.3)'; ctx.lineWidth = 1;
      const gridSize = 100;
      const startX = - (viewOffset.x % gridSize); const startY = - ((viewOffset.y + recoilOffset.y) % gridSize);
      for (let x = startX; x < width; x += gridSize) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke(); }
      for (let y = startY; y < height; y += gridSize) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke(); }

      if (!isPaused && isActive) {
        updateRecoil();
        setTargets(prev => prev.map(t => {
          let nx = t.x + (t.vx || 0); let ny = t.y + (t.vy || 0);
          const centerX = WORLD_WIDTH / 2; const centerY = WORLD_HEIGHT / 2;
          if (nx < centerX - SPAWN_WIDTH / 2 || nx > centerX + SPAWN_WIDTH / 2) t.vx = -(t.vx || 0);
          if (ny < centerY - SPAWN_HEIGHT / 2 || ny > centerY + SPAWN_HEIGHT / 2) t.vy = -(t.vy || 0);
          return { ...t, x: nx, y: ny };
        }));
        if (mode === TrainingMode.TRACKING) {
          targets.forEach(t => {
            const screenX = (t.x - viewOffset.x) + width / 2; const screenY = (t.y - (viewOffset.y + recoilOffset.y)) + height / 2;
            const dist = Math.hypot(width / 2 - screenX, height / 2 - screenY);
            if (dist < t.radius) setStats(s => ({ ...s, trackingDuration: s.trackingDuration + deltaTime }));
          });
        }
      }

      targets.forEach(t => {
        const screenX = (t.x - viewOffset.x) + width / 2; const screenY = (t.y - (viewOffset.y + recoilOffset.y)) + height / 2;
        if (screenX > -t.radius && screenX < width + t.radius && screenY > -t.radius && screenY < height + t.radius) {
          ctx.beginPath(); ctx.arc(screenX, screenY, t.radius, 0, Math.PI * 2);
          ctx.fillStyle = currentProfile.targetSettings.color; ctx.shadowBlur = 20; ctx.shadowColor = currentProfile.targetSettings.color; ctx.fill();
          ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke(); ctx.shadowBlur = 0;
        }
      });

      const weaponBaseX = width / 2 + (width * 0.2); const weaponBaseY = height - 60;
      const weaponX = weaponBaseX + weaponSway.x; const weaponY = weaponBaseY + weaponSway.y;
      const tilt = weaponSway.x * 0.004; ctx.save(); ctx.translate(weaponX, weaponY); ctx.rotate(tilt);
      const gradient = ctx.createLinearGradient(-35, 0, 35, 0); gradient.addColorStop(0, '#1e293b'); gradient.addColorStop(0.5, '#64748b'); gradient.addColorStop(1, '#0f172a');
      ctx.fillStyle = gradient; ctx.beginPath(); ctx.roundRect(-40, -280, 80, 400, 12); ctx.fill();
      ctx.fillStyle = '#020617'; ctx.fillRect(-15, -260, 30, 90);
      if (muzzleFlash > 0) {
        ctx.beginPath(); const flashGrad = ctx.createRadialGradient(0, -290, 0, 0, -290, 70);
        flashGrad.addColorStop(0, '#fbbf24'); flashGrad.addColorStop(0.3, 'rgba(251, 191, 36, 0.6)'); flashGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = flashGrad; ctx.arc(0, -290, 70, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();

      const { crosshair } = currentProfile;
      const cx = width / 2; const cy = height / 2; const len = crosshair.size; const gap = crosshair.gap;
      ctx.save();
      if (crosshair.outline) {
        ctx.strokeStyle = 'rgba(0,0,0,0.8)'; ctx.lineWidth = crosshair.thickness + 2;
        ctx.beginPath(); ctx.moveTo(cx - len - gap, cy); ctx.lineTo(cx - gap, cy); ctx.moveTo(cx + len + gap, cy); ctx.lineTo(cx + gap, cy);
        ctx.moveTo(cx, cy - len - gap); ctx.lineTo(cx, cy - gap); ctx.moveTo(cx, cy + len + gap); ctx.lineTo(cx, cy + gap); ctx.stroke();
      }
      ctx.strokeStyle = crosshair.color; ctx.lineWidth = crosshair.thickness;
      ctx.beginPath(); ctx.moveTo(cx - len - gap, cy); ctx.lineTo(cx - gap, cy); ctx.moveTo(cx + len + gap, cy); ctx.lineTo(cx + gap, cy);
      ctx.moveTo(cx, cy - len - gap); ctx.lineTo(cx, cy - gap); ctx.moveTo(cx, cy + len + gap); ctx.lineTo(cx, cy + gap); ctx.stroke();
      ctx.restore();

      if (!isPaused) { setWeaponSway(prev => ({ x: prev.x * 0.88, y: prev.y * 0.88 })); if (muzzleFlash > 0) setMuzzleFlash(prev => Math.max(0, prev - deltaTime)); }
    }
    lastTimeRef.current = time; requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => { requestRef.current = requestAnimationFrame(animate); return () => cancelAnimationFrame(requestRef.current!); }, [targets, viewOffset, recoilOffset, muzzleFlash, weaponSway, isPaused, currentProfile]);

  const handlePointerMove = (e: MouseEvent) => {
    if (!isActive || isPaused || !document.pointerLockElement) return;
    const sens = currentProfile.sensitivity * 0.7; const dx = e.movementX * sens; const dy = e.movementY * sens;
    setViewOffset(prev => ({ x: Math.max(WORLD_WIDTH / 2 - 800, Math.min(WORLD_WIDTH / 2 + 800, prev.x + dx)), y: Math.max(WORLD_HEIGHT / 2 - 600, Math.min(WORLD_HEIGHT / 2 + 600, prev.y + dy)) }));
    setWeaponSway(prev => ({ x: Math.max(-120, Math.min(120, prev.x + dx * 1.6)), y: Math.max(-60, Math.min(60, prev.y + dy * 1.0)) }));
  };

  const handleShoot = () => {
    if (!isActive || isPaused) return; setMuzzleFlash(50); const canvas = canvasRef.current; if (!canvas) return;
    const { width, height } = canvas; const impactX = width / 2; const impactY = height / 2; let hitOccurred = false; const now = Date.now();
    setTargets(prev => {
      let hitId: string | null = null;
      prev.forEach(t => {
        const screenX = (t.x - viewOffset.x) + width / 2; const screenY = (t.y - (viewOffset.y + recoilOffset.y)) + height / 2;
        if (Math.hypot(impactX - screenX, impactY - screenY) < t.radius) { hitId = t.id; hitOccurred = true; }
      });
      if (hitId) {
        setStats(s => ({ ...s, hits: s.hits + 1, reactionTimes: [...s.reactionTimes, now - (prev.find(t => t.id === hitId)?.spawnTime || now)] }));
        return prev.map(t => t.id === hitId ? createTarget() : t);
      }
      return prev;
    });
    if (!hitOccurred) setStats(s => ({ ...s, misses: s.misses + 1 }));
  };

  useEffect(() => {
    const handlePointerLockChange = () => { if (!document.pointerLockElement && isActive) setIsPaused(true); };
    const handleKeyDown = (e: KeyboardEvent) => { if (e.key === 'Escape' && isActive) { if (!isPaused) document.exitPointerLock(); else handleResume(); } };
    window.addEventListener('mouseup', () => setIsFiring(false)); window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousemove', handlePointerMove); document.addEventListener('pointerlockchange', handlePointerLockChange);
    return () => { window.removeEventListener('mouseup', () => setIsFiring(false)); window.removeEventListener('keydown', handleKeyDown); document.removeEventListener('mousemove', handlePointerMove); document.removeEventListener('pointerlockchange', handlePointerLockChange); };
  }, [isActive, isPaused, currentProfile.sensitivity, viewOffset]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isActive || isPaused) return;
    if ((e.button === 0 ? 'left' : e.button === 2 ? 'right' : null) === currentProfile.shootingButton) { setIsFiring(true); fireStartTime.current = Date.now(); if (mode !== TrainingMode.SPRAY) handleShoot(); }
  };

  useEffect(() => {
    let interval: number | null = null;
    if (isFiring && mode === TrainingMode.SPRAY && isActive && !isPaused) interval = window.setInterval(handleShoot, 90);
    return () => { if (interval) clearInterval(interval); };
  }, [isFiring, mode, isActive, isPaused, viewOffset, recoilOffset]);

  useEffect(() => { if (timeLeft === 0 && isActive === false && stats.hits + stats.misses > 0) onSessionComplete({ ...stats, endTime: Date.now() }); }, [timeLeft, isActive, stats, onSessionComplete]);

  const totalShots = stats.hits + stats.misses;
  const accuracy = totalShots === 0 ? 0 : Math.round((stats.hits / totalShots) * 100);
  const missRate = totalShots === 0 ? 0 : 100 - accuracy;
  const successScore = (stats.hits * 100) + (accuracy * 10);

  return (
    <div ref={containerRef} onContextMenu={(e) => e.preventDefault()} className="relative w-full h-screen flex flex-col items-center justify-center bg-[#020617] overflow-hidden font-sans">
      
      {/* HUD */}
      <div className="absolute top-8 left-8 flex flex-col gap-2 z-10 select-none pointer-events-none">
        <h2 className="text-xl font-black text-slate-500 uppercase tracking-widest">{mode} GRID</h2>
        <div className="flex gap-4">
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-4 rounded-3xl min-w-[130px]">
            <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">VURUŞ</p>
            <p className="text-4xl font-mono text-emerald-400 font-bold leading-none">{stats.hits}</p>
          </div>
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-4 rounded-3xl min-w-[130px]">
            <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">BAŞARI PUANI</p>
            <p className="text-4xl font-mono text-blue-400 font-bold leading-none">{successScore}</p>
          </div>
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-4 rounded-3xl min-w-[130px]">
            <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">İSABET</p>
            <p className="text-4xl font-mono text-emerald-500 font-bold leading-none">%{accuracy}</p>
          </div>
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-4 rounded-3xl min-w-[130px]">
            <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">ISKA ORANI</p>
            <p className="text-4xl font-mono text-red-500 font-bold leading-none">%{missRate}</p>
          </div>
          <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800 p-4 rounded-3xl min-w-[130px]">
            <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">SÜRE</p>
            <p className="text-4xl font-mono text-amber-400 font-bold leading-none">{timeLeft}s</p>
          </div>
        </div>
      </div>

      {/* PAUSE MENU */}
      {isPaused && isActive && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/80 backdrop-blur-xl p-8 overflow-y-auto">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 p-10 rounded-[3rem] shadow-2xl space-y-8 my-auto">
            <h2 className="text-4xl font-black text-white italic tracking-tighter text-center uppercase">Simülasyon Duraklatıldı</h2>
            
            {!showSettings ? (
              <div className="grid grid-cols-1 gap-4">
                <button onClick={handleResume} className="group w-full bg-white text-slate-950 py-6 rounded-2xl font-black text-xl flex items-center justify-center gap-4 hover:bg-blue-500 hover:text-white transition-all shadow-xl">
                  <Play className="fill-current" /> DEVAM ET
                </button>
                <button onClick={() => setShowSettings(true)} className="w-full bg-slate-800 text-slate-400 py-6 rounded-2xl font-black text-xl flex items-center justify-center gap-4 hover:bg-slate-700 transition-all">
                  <Settings /> AYARLAR
                </button>
                <button onClick={handleAbort} className="w-full bg-red-500/10 text-red-500 py-6 rounded-2xl font-black text-xl flex items-center justify-center gap-4 hover:bg-red-500 hover:text-white transition-all">
                  <LogOut /> AYRIL
                </button>
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
                <div className="flex justify-between items-center mb-4">
                   <h3 className="text-xl font-bold text-blue-400 uppercase tracking-widest">Nişangah & Genel Ayarlar</h3>
                   <button onClick={() => setShowSettings(false)} className="text-slate-500 hover:text-white font-bold">GERİ DÖN</button>
                </div>

                <div className="flex justify-center gap-4 py-4">
                   <CrosshairPreview profile={currentProfile} label="Mevcut" />
                   {previewCrosshair && <CrosshairPreview profile={previewCrosshair} label="Yeni" />}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between"><span className="text-xs font-black text-slate-500 uppercase">Hassasiyet</span><span className="text-blue-400 font-mono font-bold">{currentProfile.sensitivity}</span></div>
                      <input type="range" min="0.01" max="5" step="0.01" value={currentProfile.sensitivity} onChange={(e)=>setCurrentProfile({...currentProfile, sensitivity: parseFloat(e.target.value)})} className="w-full accent-blue-500" />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase"><span>Boyut</span><span>{currentProfile.crosshair.size}</span></div>
                      <input type="range" min="0.5" max="20" step="0.5" value={currentProfile.crosshair.size} onChange={(e)=>setCurrentProfile({...currentProfile, crosshair: {...currentProfile.crosshair, size: parseFloat(e.target.value)}})} className="w-full accent-emerald-500" />
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-800 space-y-4">
                  <span className="text-xs font-black text-slate-500 uppercase">Valorant Kodu Yükle</span>
                  <div className="flex gap-2">
                    <input placeholder="0;P;c;5;o;1;0t;1..." className="flex-1 bg-slate-950 border border-slate-800 p-3 rounded-xl font-mono text-sm outline-none focus:border-blue-500 placeholder:text-slate-700" value={crosshairCode} onChange={(e) => setCrosshairCode(e.target.value)} />
                    <button onClick={() => applyCrosshairCode(crosshairCode)} className="bg-blue-600 text-white px-6 py-3 rounded-xl font-black text-xs hover:bg-blue-500 transition-all uppercase">UYGULA</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {!isActive && timeLeft > 0 && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/90 backdrop-blur-2xl">
          <div className="text-center p-16 border border-white/5 rounded-[4rem] bg-slate-900/10 shadow-2xl">
            <h1 className="text-7xl font-black mb-6 text-white uppercase italic leading-none">Simülasyon Hazır</h1>
            <button onClick={handleStart} className="bg-white text-slate-950 px-24 py-8 rounded-full font-black text-2xl shadow-2xl transition-all hover:scale-110 hover:bg-emerald-500 hover:text-white group flex items-center gap-6 mx-auto">
              BAŞLAT <Zap className="group-hover:fill-current w-8 h-8" />
            </button>
          </div>
        </div>
      )}
      <canvas ref={canvasRef} width={window.innerWidth} height={window.innerHeight} onMouseDown={handleMouseDown} className={`w-full h-full ${isPaused ? 'cursor-default' : 'cursor-none'}`} />
    </div>
  );
};

export default AimEngine;
